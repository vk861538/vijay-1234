#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <string>
#include <cstring>

#define PERMS 0666
#define MAXBUF 10

using namespace std;
