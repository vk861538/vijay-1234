#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <string>
#include <cstring>

#define PERMS 0666
#define MAXBUF 10

using namespace std;
class Email
{
    private:
    string Name;
    string domain;
    char specialcharacter;
    public:
    Email(){}
    Email(string n,string dname,char s){Name=n;domain=dname;specialcharacter=s;}
    
    void getData()
    {
        cout<<"Enter Name"<<endl;
        cin>>Name;
        cout<<"Enter Spaecialcharacter";
        cin>>specialcharacter;
        cout<<"Enter doamin ";
        cin>>domain;
    }
    
    void Validate()
    {
        if(domain == "abc.com")
            cout<<"Valid Emailid";
    else
        cout<<"Invalid Emailid";
    }
    
    void Display()
    {
        cout<<Name<<endl;
        cout<<specialcharacter<<endl;
        cout<<domain<<endl;
    }
};



