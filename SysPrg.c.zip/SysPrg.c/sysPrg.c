#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
      int i,n;
      scanf("%d",&n);
      if(fork()==0)
      {
             for(int i=1;i<n;i++){
                if(i%2== 0)
                  printf("\t%d\n",i);
      } 
      }
      else
      {  
          for(i=1;i<n;i++)
              if(i%2 !=0)
                printf("%d\n",i);
                
      }
}
                  
      
          
      

